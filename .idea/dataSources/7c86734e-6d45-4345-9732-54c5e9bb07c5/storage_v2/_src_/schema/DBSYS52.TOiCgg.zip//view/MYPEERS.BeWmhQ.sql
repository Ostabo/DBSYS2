create view MYPEERS as
SELECT distinct p."PNR",p."NAME",p."JAHRG",p."EINDAT",p."GEHALT",p."BERUF",p."ANR",p."VNR",p."ACCOUNT" 
from pers p, pers u, dual
where p.account = USER
or u.vnr = p.pnr
/

