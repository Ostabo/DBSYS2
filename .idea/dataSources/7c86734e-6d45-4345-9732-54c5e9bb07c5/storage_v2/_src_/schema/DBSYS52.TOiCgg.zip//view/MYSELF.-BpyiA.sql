create view MYSELF as
SELECT "PNR","NAME","JAHRG","EINDAT","GEHALT","BERUF","ANR","VNR","ACCOUNT","DUMMY"
FROM pers p, dual
WHERE p.account = USER
/

