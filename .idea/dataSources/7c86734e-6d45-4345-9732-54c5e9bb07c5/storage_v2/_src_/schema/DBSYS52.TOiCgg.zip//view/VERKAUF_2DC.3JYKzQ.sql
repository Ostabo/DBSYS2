create view VERKAUF_2DC as
(
    select 
        DECODE(GROUPING(k.age), 1, 'Alle', k.age) AS Age,
        DECODE(GROUPING(p.produktgruppe), 1, 'Alle', p.produktgruppe) AS Produktgruppe,
        sum(v.anzahl) as Anzahl_Käufe
    from kunde k, produkt p, verkauf v
    where TO_CHAR(v.datum, 'YYYY') = '2022' --2020 keine einträge
    and v.produktid = p.produktid
    and v.kundenid = k.kundenid
    group by cube(k.age, p.produktgruppe)
)
/

